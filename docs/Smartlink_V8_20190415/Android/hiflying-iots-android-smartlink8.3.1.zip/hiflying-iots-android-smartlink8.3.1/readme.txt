hiflying-iots-android-smartlink-x.x.x.jar              					------- the core library of smartlink
hiflying-iots-android-smartlink-demo			 						------- the smartlink android demo project
SmartLink_App_Development_Guide    									------- the smartlink android app development guide
hiflying-iots-android-smartlink-demo-x.x.x.apk 			        ------- the runnable smartlink android demo apps
docs																						------- the api documents